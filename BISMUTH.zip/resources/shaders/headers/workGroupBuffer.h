/*
    This contains the info for a single invocation of the
    object culling compute shader. It tells the shader
    which input sprites to process. The input sprites
    can be found inside the input sprite buffer.
*/
struct WorkGroup {
    uint inputSpriteIndex;
    uint inputSpriteCount;
    // This tells the compute shader where to output the indicies in the culled index buffer
    uint culledIndexBufferOutputIndex;
};

#define MAX_WORK_GROUP_COUNT 10000

STORAGE_BUFFER(WORK_GROUP_BUFFER_BINDING) WorkGroupBuffer {
    WorkGroup u_workGroups[CPP_ONLY(0)];
};